

# chạy Web trên Cloud Heroku 

1. Code đưa lên Github 

2. Github có chứa file thông tin liên quan tới Thư viện cần cài đặt 
- package.json 

3. Github chứa file mô tả thực thi dự án Web bằng Nodejs
- Procfile 

4. Kết nối Heroku App với Github 

5. Deploy

6. Run / Lauch Web site 

